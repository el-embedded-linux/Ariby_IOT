import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *

DEFAULTSTYLE = """
QProgressBar{
    border:2px solid grey;
    border-radius:5px;
    text-align:center;
    background-color:rgb(255,255,255);
    color:rgb(41,41,41);
    font-size:13px;
    padding:2px
}
QProgressBar::chunk{
    background-color:rgb(106,230,197);
    width:10px;
}
"""

class LoadingMain(QStackedWidget):
    def __init__(self, filename, title, parent=None):
        QStackedWidget.__init__(self, parent)
        self.resize(800, 480)
        self.setStyleSheet("background-color:rgb(106,230,197)")
        self.movie = QMovie(filename, QByteArray(), self)

        self.setWindowTitle(title)

        self.movieScreen = QLabel()
        self.movieScreen.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.movieScreen.setAlignment(Qt.AlignCenter)

        self.pro = QProgressBar()
        value = 40
        self.pro.setValue(value)
        self.pro.setTextVisible(False)
        if value == self.pro.maximum():
            self.setCurrentIndex(1)
        else:
            self.pro.setStyleSheet(DEFAULTSTYLE)

        mainLayout = QVBoxLayout()
        mainLayout.addWidget(self.movieScreen)
        mainLayout.addWidget(self.pro)

        self.setLayout(mainLayout)

        self.movie.setCacheMode(QMovie.CacheAll)
        self.movie.setSpeed(100)
        self.movieScreen.setMovie(self.movie)
        self.movie.start()

    def setCurrentIndex(self, index):
        self.fadeUi = FadeWidget(self.currentWidget(), self.widget(index))
        QStackedWidget.setCurrentIndex(self, index)


class FadeWidget(QWidget):
    def __init__(self, before, after):
        QWidget.__init__(self, after)

        self.old_pixmap = QPixmap(after.size())
        before.render(self.old_pixmap)
        self.pixmap_opacity = 0.5

        self.timeline = QTimeLine()
        self.timeline.valueChanged.connect(self.animate)
        self.timeline.finished.connect(self.close)
        self.timeline.setDuration(333)
        self.timeline.start()

        self.resize(after.size())
        self.show()

    def paintEvent(self, event):
        painter = QPainter()
        painter.begin(self)
        painter.setOpacity(self.pixmap_opacity)
        painter.drawPixmap(0, 0, self.old_pixmap)
        painter.end()

    def animate(self, value):
        self.pixmap_opacity = 1.0 - value
        self.repaint()


if __name__ == "__main__":
    gif = "start.gif"
    app = QApplication(sys.argv)
    ui = LoadingMain(gif, "Ariby")
    ui.show()
    sys.exit(app.exec_())