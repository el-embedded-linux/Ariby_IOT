import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *

DEFAULTSTYLE = """
QProgressBar{
    border:2px solid grey;
    border-radius:5px;
    text-align:center;
    background-color:rgb(255,255,255);
    color:rgb(41,41,41);
    font-size:13px;
    padding:2px
}
QProgressBar::chunk{
    background-color:rgb(106,230,197);
    width:10px;
}
"""


class Thread(QThread, QWidget):
    value = pyqtSignal(int)

    def __init__(self):
        QThread.__init__(self)
        self.mutex = QMutex()
        self.cnt = 0
        self._status = True
        self.pixmap_opacity = 1.0

    def run(self):
        while True:
            self.mutex.lock()
            if 100 == self.cnt:
                self.msleep(1000)
                form.setStyleSheet("background-color:rgb(41,41,41)")
                form.movieScreen.setVisible(False)
                form.pgsb.setVisible(False)
                break
            self.cnt += 1
            self.value.emit(self.cnt)
            self.msleep(30)
            self.mutex.unlock()


class Form(QWidget):
    def __init__(self, filename):
        QWidget.__init__(self, flags=Qt.Widget)
        self.resize(800, 480)
        self.movie = QMovie(filename, QByteArray(), self)
        self.pgsb = QProgressBar()
        self.pgsb.setStyleSheet(DEFAULTSTYLE)
        self.pgsb.setTextVisible(False)
        self.th = Thread()
        self.init_widget()
        self.th.start()

    def init_widget(self):
        self.setWindowTitle("ARIBY")
        self.setStyleSheet("background-color:rgb(106,230,197)")
        self.th.value.connect(self.pgsb.setValue)
        self.movieScreen = QLabel()
        self.movieScreen.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.movieScreen.setAlignment(Qt.AlignCenter)
        self.mainLayout = QVBoxLayout()
        self.mainLayout.addWidget(self.movieScreen)
        self.mainLayout.addWidget(self.pgsb)
        self.setLayout(self.mainLayout)
        self.movie.setCacheMode(QMovie.CacheAll)
        self.movie.setSpeed(90)
        self.movieScreen.setMovie(self.movie)
        self.movie.start()


if __name__ == "__main__":
    gif = "start.gif"
    app = QApplication(sys.argv)
    form = Form(gif)
    form.show()
    sys.exit(app.exec_())