import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *


class Test(QWidget):
    def __init__(self):
        QWidget.__init__(self)
        self.btn = QPushButton("dd")
        self.lay = QVBoxLayout()
        self.setLayout(self.lay)
        self.lay.addWidget(self.btn)
        self.btn.clicked.connect(self.fadeout)

    def fadeout(self):
        self.fadeout2(self.btn)

    def fadeout2(self, widget):
        self.effect = QGraphicsOpacityEffect()
        widget.setGraphicsEffect(self.effect)

        self.animation = QPropertyAnimation(self.effect, b"opacity")
        self.animation.setDuration(1000)
        self.animation.setStartValue(1)
        self.animation.setEndValue(0)
        self.animation.start()


app = QApplication(sys.argv)
form = Test()
form.show()
sys.exit(app.exec_())
