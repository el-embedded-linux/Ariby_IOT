# PyQt ProGramming Version 1 
# 1.레이아웃  2.실시간 시간 반영  3.클릭 시 이벤트  4.윈도우 아이콘 변경..ㅋㅋ

import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from datetime import datetime

#다이얼로그
class Test1ClickedDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.formSetting()

    #포맷
    def formSetting(self):
        self.resize(200, 200)
        self.setWindowTitle("DIALOG")
        label = QLabel("HI")
        label.setAlignment(Qt.AlignCenter)
        closeBtn = QPushButton("CLOSE")
        closeBtn.clicked.connect(self.closeDialog)
        closeBtn.setCursor(QCursor(Qt.PointingHandCursor))
        layout = QGridLayout()
        layout.addWidget(label,0,0)
        layout.addWidget(closeBtn,1,0)
        self.setLayout(layout)
        # self.showFullScreen() 풀스크린

    #이벤트
    def closeDialog(self):
        self.close()


#메인윈도우
class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.formSetting()

    #레이아웃 및 타이머
    def formSetting(self):
        self.resize(800, 480)
        self.setWindowIcon(QIcon("bycicle.png"))
        self.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.font = QFont()
        self._translate = QCoreApplication.translate
        self.centralwidget = QWidget()
        self.titleWidget = QWidget(self.centralwidget)
        self.titleWidget.resize(800, 40)
        self.horizontalLayout = QHBoxLayout(self.titleWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.titleSet()
        self.timer = QTimer(self)
        self.timer.start(1000)
        self.timer.timeout.connect(self.timeout)
        self.gridLayout = QGridLayout()
        self.gridLayout.addWidget(self.label, 1, 0, 1, 1)
        self.menuWidget = QWidget(self.centralwidget)
        self.menuWidget.setGeometry(QRect(0, 40, 800, 440))
        self.gridLayout2 = QGridLayout(self.menuWidget)
        self.horizontalLayout.addWidget(self.aribyTitle)
        self.horizontalLayout.addLayout(self.gridLayout)
        self.testAreaSet()
        self.setCentralWidget(self.centralwidget) #보완 필요

    #시간변경
    def timeout(self):
        strTime = datetime.today().strftime("%Y.%m.%d. %H:%M       ")
        self.label.setText(self._translate("Main", strTime))

    #타이틀바
    def titleSet(self):
        self.font.setFamily("Berlin Sans FB")
        self.font.setPointSize(24)
        self.font.setWeight(50)
        self.aribyTitle = QLabel(self.titleWidget)
        self.aribyTitle.setFont(self.font)
        self.aribyTitle.setStyleSheet("color: rgb(140, 215, 144);")
        self.aribyTitle.setAlignment(Qt.AlignLeft)
        self._translate = QCoreApplication.translate
        self.setWindowTitle(self._translate ("Main", "ARIBY"))
        self.aribyTitle.setText(self._translate ("Main", "  ARIBY"))
        self.label = QLabel(self.titleWidget)
        self.font.setFamily("Bahnschrift Light")
        self.font.setPointSize(13)
        self.label.setFont(self.font)
        self.label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)

    #라벨 4개
    def testAreaSet(self):
        self.test = []
        self.font.setPointSize(11)
        row = 0; col = 0
        for i in range(0, 4, 1):
            self.test.append(QLabel(self.menuWidget))
            self.test[i].setText("TEST")
            self.test[i].setFont(self.font)
            self.test[i].setAlignment(Qt.AlignCenter)
            self.test[i].setStyleSheet("background-color: rgb(140, 215, 144);")
            self.test[i].setCursor(QCursor(Qt.PointingHandCursor))
            if (col == 2):
                row = 1; col = 0
            self.gridLayout2.addWidget(self.test[i], row, col, 1, 1)
            col += 1
        self.test[0].mousePressEvent = self.test1Clicked

        # 이벤트 추가 예정
        self.test[3].mousePressEvent = self.test4Clicked

    #이벤트 함수1
    def test1Clicked(self, event):
        lDig = Test1ClickedDialog()
        lDig.exec_()

    #이벤트함수 추가 예정..

    #이벤트 함수4
    def test4Clicked(self, event):
        sys.exit()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    ui = Main()
    ui.show()
    # ui.showFullScreen() 풀스크린
    app.exec_()

