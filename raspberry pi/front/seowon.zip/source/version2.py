# PyQt ProGramming Version 2
#

import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from datetime import datetime

#블루투스연
class Test1ClickedDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.formSetting()

    #포맷
    def formSetting(self):
        self.resize(200, 200)
        #self.setWindowTitle("DIALOG")

        label = QLabel("HI")
        label.setAlignment(Qt.AlignCenter)

        closeBtn = QPushButton("CLOSE")
        closeBtn.clicked.connect(self.closeDialog)
        closeBtn.setCursor(QCursor(Qt.PointingHandCursor))

        layout = QGridLayout()
        layout.addWidget(label,0,0)
        layout.addWidget(closeBtn,1,0)

        self.setLayout(layout)
        #self.showFullScreen()

    #이벤트
    def closeDialog(self):
        self.close()

#다이얼로그2
class Test2ClickedDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.formSetting()

    #포맷
    def formSetting(self):
        self.resize(200, 200)
        #self.setWindowTitle("DIALOG")

        label = QLabel("HI")
        label.setAlignment(Qt.AlignCenter)

        closeBtn = QPushButton("CLOSE")
        closeBtn.clicked.connect(self.closeDialog)
        closeBtn.setCursor(QCursor(Qt.PointingHandCursor))

        layout = QGridLayout()
        layout.addWidget(label,0,0)
        layout.addWidget(closeBtn,1,0)

        self.setLayout(layout)
        #self.showFullScreen()

    #이벤트
    def closeDialog(self):
        self.close()




#메인윈도우
class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.formSetting()

    #레이아웃 및 타이머
    def formSetting(self):
        self.resize(800, 480)
        #self.setWindowIcon(QIcon("bycicle.png"))
        self.setStyleSheet("background-color: rgb(41, 41, 41);")

        self.font = QFont()
        self._translate = QCoreApplication.translate
        self.centralWidget = QWidget()

        self.titleWidget = QWidget(self.centralWidget)
        self.titleWidget.resize(800, 40)

        self.horizontalLayout = QHBoxLayout(self.titleWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)

        self.titleSet()

        self.timer = QTimer(self)
        self.timer.start(1000)
        self.timer.timeout.connect(self.timeout)

        self.gridLayout = QGridLayout()
        self.gridLayout.addWidget(self.time, 1, 0)
        self.gridLayout.addWidget(self.weather, 1, 1)

        self.menuWidget = QWidget(self.centralWidget)
        self.menuWidget.setGeometry(QRect(0, 40, 800, 440))

        self.horizontalLayout.addWidget(self.aribyTitle)
        self.horizontalLayout.addLayout(self.gridLayout)

        self.testAreaSet()

        self.setCentralWidget(self.centralWidget)

    #시간변경
    def timeout(self):
        strTime = datetime.today().strftime("%Y.%m.%d. %H:%M       ")
        self.time.setText(self._translate("Main", strTime))

    #타이틀바
    def titleSet(self):
        self.font.setFamily("Berlin Sans FB")
        self.font.setPointSize(24)
        self.font.setWeight(50)

        self.setWindowTitle(self._translate ("Main", "ARIBY"))

        self.aribyTitle = QLabel(self.titleWidget)
        self.aribyTitle.setFont(self.font)
        self.aribyTitle.setStyleSheet("color: rgba(106, 230, 197);")
        self.aribyTitle.setText(self._translate ("Main", "  ARIBY"))

        self.font.setFamily("Bahnschrift Light")
        self.font.setPointSize(13)

        self.time = QLabel(self.titleWidget)
        self.time.setFont(self.font)
        self.time.setStyleSheet("color: rgb(255, 255, 255)")
        self.time.setAlignment(Qt.AlignRight | Qt.AlignVCenter)

        self.weather = QLabel(self.titleWidget)
        pix = QPixmap('snowy.png')
        self.weather.setPixmap(pix)
        self.weather.setAlignment(Qt.AlignRight | Qt.AlignVCenter)

    #라벨 4개
    def testAreaSet(self):
        self.gridLayout2 = QGridLayout(self.menuWidget)

        self.test = []
        self.font.setPointSize(11)
        row = 0; col = 0

        for i in range(0, 4, 1):
            self.test.append(QLabel(self.menuWidget))
            self.test[i].setFont(self.font)
            self.test[i].setAlignment(Qt.AlignCenter)
            self.test[i].setStyleSheet("image:url('sunny.png')")
            if (col == 2):
                row = 1; col = 0
            self.gridLayout2.addWidget(self.test[i], row, col)
            col += 1

        self.test[0].mousePressEvent = self.test1Clicked

        # 이벤트 추가 예정

        self.test[3].mousePressEvent = self.test4Clicked

    #이벤트 함수1
    def test1Clicked(self, event):
        lDig = Test1ClickedDialog()
        lDig.exec_()

    #이벤트함수 추가 예정..

    #이벤트 함수4
    def test4Clicked(self, event):
        sys.exit()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    ui = Main()
    ui.show()
    #ui.showFullScreen()
    app.exec_()

